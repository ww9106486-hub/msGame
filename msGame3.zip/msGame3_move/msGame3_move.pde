float px, py; //플레이어 위치
float ps = 20; //플레이어 크기(반지름 기준)

void setup() {
  size(1000, 1000);
  reset(); //변수 초기화
}


//리셋
void reset() {
  px = width / 2;
  py = height - 100;
}

void draw() {
    background(20, 20, 40);
    
    handlePlayer();
    drawObjects();
}



void drawObjects() {
  //우주선
  fill(0, 255, 0);
  triangle(px, py - ps, px - ps, py + ps, px + ps, py + ps);

}





//============================sprint 2 
void handlePlayer() {
  //키보드
  if (keyPressed) {
    if (key == 'w' || key == 'W') py -= 7;
    if (key == 's' || key == 'S') py += 7;
    if (key == 'a' || key == 'A') px -= 7;
    if (key == 'd' || key == 'D') px += 7;
  }

  //화면 밖으로 못 나가게
  if (px < ps) 
    px = ps;
  
  if (px > width - ps) 
    px = width - ps;
  
  if (py < ps) 
     py = ps;
  
  if (py > height - ps) 
    py = height - ps;
}
