int N = 20; //운석의 최대 개수
float[] mx = new float[N];
float[] my = new float[N];
float[] ms = new float[N]; //운석 속도
float[] mr = new float[N]; //운석 크기(반지름)
boolean[] live = new boolean[N]; //운석 생존 여부
float px, py; //플레이어 위치
float ps = 20; //플레이어 크기(반지름 기준)

int state = 0; //0게임 진행 중, 1게임 오버 
int life = 3;  //남은 목숨
int score = 0; //점수



void setup() {
  size(1000, 1000);
  reset(); //변수 초기화
}


//리셋
void reset() {
  px = width / 2;
  py = height - 100;
  life = 3;
  score = 0;
  state = 0;
  
  for (int i = 0; i < N; i++) {
    mx[i] = random(width);
    my[i] = random(-1000, -50); 
    ms[i] = random(3, 8);
    mr[i] = random(15, 35);
    live[i] = true;
  }
}

void draw() {
    background(20, 20, 40);
    drawObjects();
  }



//============================sprint 1
void drawObjects() {
  //우주선
  fill(0, 255, 0);
  triangle(px, py - ps, px - ps, py + ps, px + ps, py + ps);
}
