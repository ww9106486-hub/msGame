int N = 20; // 화면에 나타날 운석의 최대 개수
float[] mx = new float[N];
float[] my = new float[N];
float[] ms = new float[N]; // 운석 속도
float[] mr = new float[N]; // 운석 크기(반지름)
boolean[] live = new boolean[N]; // 운석 생존 여부
float px, py; // 플레이어 위치
float ps = 20; // 플레이어 크기(반지름 기준)

int state = 0; // 0: 게임 진행 중, 1: 게임 오버 (State Machine)
int life = 3;  // 남은 목숨
int score = 0; // 피한 운석 개수(점수)

void setup() {
  size(1000, 1000);
  reset(); // 처음 시작할 때 변수들 초기화 세팅
}

// 게임을 초기 상태로 돌리는 함수 (강의 자료의 void init() 참고)
void reset() {
  px = width / 2;
  py = height - 100;
  life = 3;
  score = 0;
  state = 0;
  
  for (int i = 0; i < N; i++) {
    mx[i] = random(width);
    my[i] = random(-1000, -50); 
    ms[i] = random(3, 8);
    mr[i] = random(15, 35);
    live[i] = true;
  }
}

void draw() {
  // 상태 머신(State Machine)을 이용한 화면 분기
  if (state == 0) {
    play(); // 게임 중일 때
  } else if (state == 1) {
    gameOver(); // 게임 오버일 때
  }
}

// ----------------- 게임 진행 화면 -----------------
void play() {
  background(20, 20, 40);
  
  // 1. 키보드 움직임 처리
  if (keyPressed) {
    if (key == 'w' || key == 'W') py -= 7;
    if (key == 's' || key == 'S') py += 7;
    if (key == 'a' || key == 'A') px -= 7;
    if (key == 'd' || key == 'D') px += 7;
  }
  
  // 플레이어가 화면 밖으로 못 나가게 막기
  if (px < ps) 
    px = ps;
  
  if (px > width - ps) 
    px = width - ps;
  
  if (py < ps) 
     py = ps;
  
  if (py > height - ps) 
    py = height - ps;
  
  // 2. 플레이어 그리기 (초록색 삼각형)
  fill(0, 255, 0);
  triangle(px, py - ps, px - ps, py + ps, px + ps, py + ps);
  
  // 3. 운석 떨어뜨리기 및 충돌 처리
  for (int i = 0; i < N; i++) {
    if (live[i]) {
      my[i] += ms[i]; // 아래로 이동
      
      // 운석 그리기
      fill(150);
      circle(mx[i], my[i], mr[i] * 2);
      
      // 충돌 검사 (dist 함수 사용)
      if (dist(px, py, mx[i], my[i]) < ps + mr[i]) {
        live[i] = false; // 부딪힌 운석은 사라짐
        life--;          // 목숨 1 깎임
        
        // 목숨이 0이 되면 게임 오버 상태로 변경
        if (life <= 0) {
          state = 1; 
        }
      }
      
      // 화면 밑으로 무사히 지나간 운석 처리 (점수 오름)
      if (my[i] > height + mr[i]) {
        score++; // 피했으므로 점수 1점 추가
        my[i] = random(-200, -50); // 위에서 다시 떨어지게 재활용
        mx[i] = random(width);
        live[i] = true;
      }
    }
  }
  
  // 4. 왼쪽 위에 점수와 목숨 표시
  fill(255);
  textSize(30);
  text("Score: " + score, 20, 50);
  text("Life: " + life, 20, 90);
}

// ----------------- 게임 오버 화면 -----------------
void gameOver() {
  background(0); // 까만 배경
  
  fill(255, 0, 0);
  textSize(80);
  text("GAME OVER", width / 2, height / 2 - 50);
  
  fill(255);
  textSize(40);
  text("Final Score: " + score, width / 2, height / 2 + 30);
  
  textSize(25);
  text("Press 'R' to Restart", width / 2, height / 2 + 100);
    
  // R 키를 누르면 게임 초기화하고 다시 시작
  if (keyPressed) {
    if (key == 'r' || key == 'R') {
      reset();
    }
  }
}
